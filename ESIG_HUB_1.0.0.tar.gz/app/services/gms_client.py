import socket
import threading
import json
import time
import datetime
import asyncio
from typing import Dict, Optional, Callable
from loguru import logger
from app.core.config import settings
from app.core.constants import AppStatus, AppErrorCode


class GMSClient:
    """[SERVICE] Low-level Socket handler for GMS"""

    def __init__(self, sio):
        self._sio = sio
        self._sock = None
        self._lock = threading.Lock()
        self._loop = None
        self._on_message_callback: Optional[Callable] = None
        self._on_status_callback: Optional[Callable] = None

        self.gms_ip = settings.GMS_IP
        self.gms_port = settings.GMS_PORT
        self.stats = {"rx": 0, "tx": 0}

    def set_loop(self, loop):
        self._loop = loop

    def set_callbacks(self, on_message=None, on_status=None):
        self._on_message_callback = on_message
        self._on_status_callback = on_status

    def is_connected(self) -> bool:
        return self._sock is not None

    def connect(self):
        with self._lock:
            try:
                self._broadcast_status(
                    AppStatus.CONNECTING, f"Connecting to {self.gms_ip}..."
                )
                self._sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                self._sock.settimeout(5.0)  # 5 seconds timeout
                self._sock.connect((self.gms_ip, self.gms_port))
                self._sock.settimeout(None)  # Reset to blocking for subsequent reads
                logger.success(f"Connected to GMS at {self.gms_ip}:{self.gms_port}")
                self._broadcast_status(AppStatus.CONNECTED, "Connected")
                return self._sock
            except Exception as e:
                logger.error(f"Connect failed: {e}")
                self._broadcast_status(AppStatus.DISCONNECTED, str(e))
                self.emit_error(AppErrorCode.SOCKET_ERROR, str(e))
                return None

    def disconnect(self):
        with self._lock:
            if self._sock:
                try:
                    self._sock.close()
                except:
                    pass
                self._sock = None
                self._broadcast_status(AppStatus.DISCONNECTED, "Disconnected")

    def read_loop(self, running_flag_func):
        buffer = b""
        while running_flag_func() and self._sock:
            try:
                data = self._sock.recv(4096)
                if not data:
                    break
                buffer += data
                while b"\r\n" in buffer:
                    line, buffer = buffer.split(b"\r\n", 1)
                    if line.strip():
                        self._handle_raw_message(line)
            except Exception as e:
                logger.error(f"Read Loop Error: {e}")
                break

    def _handle_raw_message(self, raw_bytes):
        try:
            msg_str = raw_bytes.decode("utf-8")
            data = json.loads(msg_str)
            self.stats["rx"] += 1

            # Extract msgType for specific events
            msg_type = data.get("header", {}).get("msgType", "Unknown")

            # 1. Log Event (Generic)
            self.emit_log("recv", msg_type, data)

            # 2. Specific Data Event (For easier FE integration)
            self.emit_socket(f"gms:data:{msg_type}", data)

            if self._on_message_callback:
                self._on_message_callback(data)

        except json.JSONDecodeError:
            self.emit_error(AppErrorCode.INVALID_JSON, "Malformed JSON from GMS")
        except Exception as e:
            logger.error(f"Error handling message: {e}")
            self.emit_error(AppErrorCode.INTERNAL_ERROR, str(e))

    def send_request(
        self, msg_type: str, client_code: str, channel_id: str, body: Dict
    ) -> bool:
        req_id = f"req_{int(time.time())}_{msg_type}"
        if "msgType" not in body:
            body["msgType"] = msg_type

        req_data = {
            "header": {
                "requestId": req_id,
                "channelId": channel_id,
                "clientCode": client_code,
                "requestTime": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            },
            "body": body,
        }

        if self.send_raw(req_data):
            self.emit_log("sent", msg_type, req_data)
            return True
        return False

    def send_raw(self, data_dict: Dict) -> bool:
        try:
            json_str = json.dumps(data_dict) + "\r\n"
            with self._lock:
                if self._sock:
                    self._sock.sendall(json_str.encode("utf-8"))
                    self.stats["tx"] += 1
                    return True
        except Exception as e:
            logger.error(f"Send Failed: {e}")
            self.emit_error(AppErrorCode.SOCKET_ERROR, str(e))
        return False

    def _broadcast_status(self, status: str, text: str):
        self.emit_socket("status_update", {"status": status, "text": text})
        if self._on_status_callback:
            self._on_status_callback(status, text)

    def emit_log(self, direction: str, msg_type: str, payload: Dict):
        self.emit_socket(
            "log",
            {
                "direction": direction,
                "msgType": msg_type,
                "payload": payload,
                "stats": self.stats,
            },
        )

    def emit_error(self, code: str, message: str):
        self.emit_socket(
            "gms:error",
            {
                "code": code,
                "message": message,
                "time": datetime.datetime.now().strftime("%H:%M:%S"),
            },
        )

    def emit_socket(self, event: str, data: Dict):
        if not self._loop:
            return
        try:
            asyncio.run_coroutine_threadsafe(self._sio.emit(event, data), self._loop)
        except:
            pass
