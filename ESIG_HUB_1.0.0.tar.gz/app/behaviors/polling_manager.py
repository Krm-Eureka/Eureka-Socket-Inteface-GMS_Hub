import threading
import time
import datetime
from typing import List, Dict
from loguru import logger
from app.services.gms_client import GMSClient
from app.core.config import settings


class PollingManager:
    """[BEHAVIOR] Manages polling logic, heartbeats and thread sessions"""

    def __init__(self, gms_client: GMSClient):
        self._gms = gms_client
        self._running = False
        self.client_code = settings.GMS_CLIENT_CODE
        self.channel_id = settings.GMS_CHANNEL_ID
        self.auto_query = False
        self.query_interval = 1.0
        self.auto_msg_types = ["LocationListMsg", "StationListMsg", "ContainerListMsg"]

    def start_service(self):
        if self._running:
            return
        self._running = True
        logger.info("Polling Manager starting session...")
        threading.Thread(target=self._session_worker, daemon=True).start()

    def stop_service(self):
        logger.info("Polling Manager stopping session...")
        self._running = False
        self._gms.disconnect()

    def update_behavior(self, config: Dict):
        self.client_code = config.get("client_code", self.client_code)
        self.channel_id = config.get("channel_id", self.channel_id)
        self.auto_query = config.get("auto_query", self.auto_query)
        if "interval_ms" in config:
            self.query_interval = float(config["interval_ms"]) / 1000.0
        if "auto_msg_types" in config:
            types = config["auto_msg_types"]
            self.auto_msg_types = [
                msg.strip() for msg in types.split(",") if msg.strip()
            ]
        logger.info(
            f"Behavior Updated: Auto={self.auto_query}, Int={self.query_interval}s"
        )

    def _session_worker(self):
        """Higher level session management"""
        while self._running:
            sock = self._gms.connect()
            if sock:
                # Connected: Start sub-behavioral loops
                hb_thread = threading.Thread(
                    target=self._heartbeat_loop, args=(sock,), daemon=True
                )
                poll_thread = threading.Thread(
                    target=self._polling_loop, args=(sock,), daemon=True
                )
                hb_thread.start()
                poll_thread.start()

                # Blocking read loop (The Service part)
                self._gms.read_loop(lambda: self._running)

            if self._running:
                logger.warning("Session lost, retrying in 5s...")
                time.sleep(5)

    def _heartbeat_loop(self, sock_ref):
        while self._running and self._gms._sock == sock_ref:
            try:
                self._gms.send_request(
                    "HeartbeatMsg", self.client_code, self.channel_id, {}
                )
                time.sleep(10)
            except:
                break

    def _polling_loop(self, sock_ref):
        while self._running and self._gms._sock == sock_ref:
            if self.auto_query:
                try:
                    for msg_type in self.auto_msg_types:
                        self._gms.send_request(
                            msg_type, self.client_code, self.channel_id, {}
                        )

                    self._gms.emit_socket(
                        "next_query_in",
                        {"duration_ms": int(self.query_interval * 1000)},
                    )
                    time.sleep(self.query_interval)
                except:
                    break
            else:
                time.sleep(0.5)
