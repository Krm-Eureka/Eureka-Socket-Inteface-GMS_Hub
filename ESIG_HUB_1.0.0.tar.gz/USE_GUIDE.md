# คู่มือการใช้งาน ESIG HUB (EA Socket Interface GMS Hub) 🚀

ระบบ Middleware สำหรับเชื่อมต่อ GMS Legacy Socket เข้ากับ Web Console และระบบ Monitoring

---

## 1. การเตรียมความพร้อม (Setup)

### การติดตั้ง Libs
ก่อนรันโปรแกรมครั้งแรก ต้องติดตั้ง Dependencies ที่จำเป็น:
```bash
pip install -r requirements.txt
```

### การตั้งค่า Environment (.env)
แก้ไขไฟล์ `.env` ในโฟลเดอร์หลักเพื่อกำหนดค่าต่างๆ:
- **GMS_IP**: IP ของเครื่อง GMS (เช่น `10.80.227.230`)
- **GMS_PORT**: พอร์ต Socket (ปกติ `24245`)
- **BFF_PORT**: พอร์ตสำหรับหน้า Web Console (เช่น `1244`)
- **MySQL Settings**: ระบุ IP, User, Password และชื่อ Database เพื่อใช้งานหน้า Health Dashboard

---

## 2. การเริ่มต้นใช้งาน (Running)

รันโปรแกรมผ่าน Python:
```bash
py main.py
```
หลังจากรันสำเร็จ สามารถเข้าใช้งานผ่าน Browser ได้ที่: `http://localhost:1244` (หรือตาม IP เครื่องที่รัน)

---

## 3. ฟีเจอร์หลักในหน้า Web Console

### 🟢 หน้า CONSOLE (Real-time Logs)
- **Service Control**: กด **START SERVICE** เพื่อเริ่มเชื่อมต่อกับ GMS
- **Polling**: เปิด **Enable Polling** เพื่อให้ระบบส่งคำสั่งเช็คสถานะ GMS อัตโนมัติวนซ้ำ
- **Unified Log**: ดูข้อความที่ส่ง (SENT) และรับ (RECV) แบบ Real-time

### 📊 หน้า HEALTH (Monitoring)
- **Server Health**: ตรวจสอบการใช้งาน CPU และ RAM ของเครื่องที่รันโปรแกรม
- **MySQL Health**: ตรวจสอบสถานะฐานข้อมูล, ความเร็วในการ Query (QPS), และอัตราการตอบสนอง (Latency)
- **Storage**: ดูขนาดของฐานข้อมูลที่ใช้งานอยู่ในปัจจุบัน

### ✉️ MANUAL REQUEST (Sidebar)
- สามารถส่งคำสั่ง JSON ไปยัง GMS ได้โดยตรงเพียงระบุ `Message Type` และ `Body JSON`

---

## 4. การจัดการไฟล์ Logs
ระบบจะบันทึก Log ทั้งหมดลงในโฟลเดอร์ `logs/`:
- **server.log**: เก็บประวัติการทำงานของระบบ (จะทำการ Rotate อัตโนมัติเมื่อไฟล์เกิน 10MB)

---

---

## 6. การแพ็คไฟล์เพื่อส่งมอบ (Packing with TAR)

หากต้องการรวบรวมไฟล์ทั้งหมดเพื่อนำไปติดตั้งที่เครื่องอื่น (Deploy):
1. **ใช้ Python (แนะนำ):** รันคำสั่งใน Terminal:
   ```bash
   py pack_project.py
   ```
2. **ใช้ PowerShell:** คลิกขวาที่ไฟล์ `pack_project.ps1` แล้วเลือก **Run with PowerShell**
3. **Manual:** หรือรันคำสั่งโดยตรง:
   ```bash
   tar -czvf ESIG_HUB.tar.gz --exclude=__pycache__ --exclude=.git --exclude=.venv --exclude=logs .
   ```
*ระบบจะสร้างไฟล์ `ESIG_HUB.tar.gz` ซึ่งตัดไฟล์ที่ไม่จำเป็นออกให้โดยอัตโนมัติ*

---

## 7. วิธีการเลือกติดตั้ง (Deployment)

### วิธีที่ 1: ติดตั้งบน Windows (IIS)
1. ติดตั้ง **HttpPlatformHandler v1.2** บน IIS
2. แตกไฟล์ที่แพ็คมาใส่ในโฟลเดอร์ Web Site
3. แก้ไขไฟล์ `web.config` ในโฟลเดอร์ `deployment/` ตรง `processPath` ให้ชี้ไปที่ `python.exe` ของท่าน
4. สร้าง Site ใน IIS และชี้มาที่โฟลเดอร์นี้

### วิธีที่ 2: ติดตั้งบน Linux (Ubuntu/CentOS)
1. แตกไฟล์: `tar -xzvf ESIG_HUB.tar.gz`
2. สร้าง Virtual Environment และติดตั้ง Requirements
3. ตั้งค่า Service ด้วย **systemd** (ใช้ไฟล์ตัวอย่างในพื้นที่ `deployment/gms-bff.service`)
4. รันคำสั่ง `sudo systemctl start esigh` เพื่อเริ่มทำงานเป็นเบื้องหลัง (Background Service)
