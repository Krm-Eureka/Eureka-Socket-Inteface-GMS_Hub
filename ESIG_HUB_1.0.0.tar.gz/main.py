import uvicorn
import socketio
import asyncio
import os
from fastapi import FastAPI, Request
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.responses import HTMLResponse
from fastapi.openapi.docs import get_swagger_ui_html
from contextlib import asynccontextmanager
from loguru import logger

# Ensure logs directory exists
if not os.path.exists("logs"):
    os.makedirs("logs")

from app.core.config import settings
from app.services.gms_client import GMSClient
from app.behaviors.polling_manager import PollingManager
from app.behaviors.system_monitor import SystemMonitor
from app.api.v1.gms_router import router as gms_router

# --- Server Orchestration ---
sio = socketio.AsyncServer(async_mode="asgi", cors_allowed_origins="*")
gms_client = GMSClient(sio)
polling_manager = PollingManager(gms_client)
system_monitor = SystemMonitor(sio)

# Configure Loguru to write to file
logger.add(
    "logs/server.log", rotation="10 MB", retention="7 days", level=settings.LOG_LEVEL
)


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Standard Startup Behavior
    loop = asyncio.get_running_loop()
    gms_client.set_loop(loop)
    system_monitor.set_loop(loop)

    logger.info("ESIG HUB Initializing: Establishing GMS Polling Behavior...")
    polling_manager.start_service()
    system_monitor.start()
    yield
    # Standard Shutdown Behavior
    logger.info("ESIG HUB Shutting Down: Cleaning up sessions...")
    polling_manager.stop_service()
    system_monitor.stop()


# --- FastAPI Initialization ---
app = FastAPI(
    title="ESIG HUB - EA Socket Interface GMS Hub", version="1.0.0", lifespan=lifespan
)

# Static & Middleware
app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

# Mount API Modules
app.include_router(gms_router)


@app.get("/", response_class=HTMLResponse, include_in_schema=False)
async def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})


@app.get("/health", tags=["Diagnostic"])
async def health_check():
    return {"status": "ok", "service": "ESIG HUB"}


@app.get("/docs", include_in_schema=False)
async def custom_swagger_ui_html():
    return get_swagger_ui_html(
        openapi_url=app.openapi_url,
        title="ESIG HUB - Swagger UI",
        swagger_js_url="/static/swagger/swagger-ui-bundle.js",
        swagger_css_url="/static/swagger/swagger-ui.css",
    )


# --- Socket.IO Event Handlers ---
@sio.event
async def connect(sid, environ):
    logger.info(f"Socket Client Connected: {sid}")
    await sio.emit(
        "status_update",
        {
            "status": "connected" if gms_client.is_connected() else "disconnected",
            "text": "Connected" if gms_client.is_connected() else "Disconnected",
        },
        to=sid,
    )


@sio.event
async def disconnect(sid):
    logger.info(f"Socket Client Disconnected: {sid}")


# Unified ASGI App
socket_app = socketio.ASGIApp(sio, app)

if __name__ == "__main__":
    logger.info(
        f"Launching Enterprise Server on {settings.BFF_HOST}:{settings.BFF_PORT}"
    )
    # Diagnostic: Print all registered routes
    logger.info("Registered Routes:")
    for route in app.routes:
        logger.info(f" -> {route.path} {getattr(route, 'methods', None)}")

    uvicorn.run(
        "main:socket_app",
        host=settings.BFF_HOST,
        port=settings.BFF_PORT,
        reload=settings.BFF_RELOAD,
    )
